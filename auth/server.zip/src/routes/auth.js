const express = require('express');
const {registerUserValidator,loginUserValidations} = require('../middlewares/vaildator.middleware')
const{authMiddleware} = require("../middlewares/auth.middleware")
const { registerUser, loginUser,getCurrentUser } = require('../controllers/auth.controller')
const router = express.Router();

router.post('/register',registerUserValidator,registerUser);
//Post /auth/login
router.post('/login',loginUserValidations, loginUser);

// GET / api/auth/me

router.get('/me',authMiddleware,getCurrentUser)
module.exports = router;
