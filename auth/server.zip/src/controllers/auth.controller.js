const userModel = require('../models/users.model');
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")

async function registerUser(req,res){
    const{username, email,password,fullName:{firstName,lastName}} = req.body;

    const isUserAlreadyExists = await userModel.findOne({
        $or:[
           {username},
           {email} 

        ]
    });

    if(isUserAlreadyExists){
        return res.status(409).json({message:"Username or email already extis"});
    }

    const hash = await bcrypt.hash(password,10);

    const user = await userModel.create({
        username,
        email,
        password:hash,
        fullName:{firstName,lastName}
    })

    const token = jwt.sign({
        id:user._id,
        username:user.username,
        email:user.email,
        role:user.role
 },process.env.JWT_SECRET,{expiresIn:'1d'})

    res.cookie('token',token,{
        httpOnly:true,
        secure:true,
        maxAge:24*60*60*1000 //1 day 
    })

    res.status(201).json({message:"User registered successfully",
        user:{
            id:user._id,
            username:user.username,
            email:user.email,
            fullName:user.fullName,
            role:user.role,
            addresses:user.addresses
        
}})

}

async function loginUser(req, res) {
    try {
        const { username, email, password } = req.body;

        const user = await userModel.findOne({
            $or: [{ username }, { email }]
        }).select('+password');

        if (!user) return res.status(401).json({ message: 'Invalid credentials' });

        const match = await bcrypt.compare(password, user.password || '');
        if (!match) return res.status(401).json({ message: 'Invalid credentials' });

        const token = jwt.sign(
            {
                id: user._id,
                username: user.username,
                email: user.email,
                role: user.role
            },
            process.env.JWT_SECRE,
            { expiresIn: '1d' }
        );

        res.cookie('token', token, {
            httpOnly: true,
            secure: true,
            maxAge: 24 * 60 * 60 * 1000
        });

        res.status(200).json({
            message: 'Logged in successfully',
            user: {
                id: user._id,
                username: user.username,
                email: user.email
            }
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
}

async function getCurrentUser(){
    return res.status(200).json({
        user: req.user
    });
}




module.exports = { registerUser, loginUser,getCurrentUser }